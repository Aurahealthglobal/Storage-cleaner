package com.storagecleaner.app.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.storagecleaner.app.core.AppContainer
import com.storagecleaner.app.data.MediaRepository
import com.storagecleaner.app.data.exclusiveCategory
import com.storagecleaner.app.data.model.CategoryBreakdown
import com.storagecleaner.app.data.model.MediaItem
import com.storagecleaner.app.data.model.StorageCategory
import com.storagecleaner.app.data.model.StorageVolumeInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class DashboardUiState(
    val isLoading: Boolean = true,
    val volumes: List<StorageVolumeInfo> = emptyList(),
    val breakdown: List<CategoryBreakdown> = emptyList(),
    val allMedia: List<MediaItem> = emptyList(),
    val largeFileCount: Int = 0,
    val largeFileBytes: Long = 0,
    val trashedCount: Int = 0,
    val errorMessage: String? = null,
) {
    val totalMediaBytes: Long get() = breakdown.sumOf { it.totalBytes }
}

class DashboardViewModel(container: AppContainer) : ViewModel() {
    private val repository: MediaRepository = container.mediaRepository

    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            try {
                val volumes = repository.getStorageVolumes()
                val media = repository.queryMedia()
                val trashed = repository.queryTrashed()

                val breakdown = StorageCategory.entries
                    .filter { it != StorageCategory.DUPLICATES && it != StorageCategory.LARGE_FILES }
                    .map { category ->
                        val matches = media.filter { item -> item.exclusiveCategory() == category }
                        CategoryBreakdown(category, matches.size, matches.sumOf { it.sizeBytes })
                    }
                val largeFiles = media.filter { it.isLarge }

                _uiState.update {
                    it.copy(
                        isLoading = false,
                        volumes = volumes,
                        breakdown = breakdown,
                        allMedia = media,
                        largeFileCount = largeFiles.size,
                        largeFileBytes = largeFiles.sumOf { file -> file.sizeBytes },
                        trashedCount = trashed.size,
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(isLoading = false, errorMessage = "Couldn't read your library — pull to retry.")
                }
            }
        }
    }
}
