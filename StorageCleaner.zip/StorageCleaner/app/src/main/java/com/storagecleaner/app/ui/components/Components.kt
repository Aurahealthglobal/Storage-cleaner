package com.storagecleaner.app.ui.components

import android.app.Activity
import android.content.IntentSender
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Circle
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.storagecleaner.app.data.model.MediaItem
import com.storagecleaner.app.data.model.MediaType
import com.storagecleaner.app.data.model.StorageCategory
import com.storagecleaner.app.thumbnail.MediaThumbnailRequest
import com.storagecleaner.app.util.formatDuration

/** Stable color mapping so the same category always reads the same way across screens. */
fun categoryColor(category: StorageCategory): Color = when (category) {
    StorageCategory.PHOTOS -> Color(0xFF7C9CFF)
    StorageCategory.VIDEOS -> Color(0xFFB388FF)
    StorageCategory.SCREENSHOTS -> Color(0xFFFFC46B)
    StorageCategory.MESSAGING_MEDIA -> Color(0xFF3DDC97)
    StorageCategory.DOWNLOADS -> Color(0xFF5FD3E3)
    StorageCategory.EDITOR_FILES -> Color(0xFFFF8FB1)
    StorageCategory.LARGE_FILES -> Color(0xFFFFA45C)
    StorageCategory.DUPLICATES -> Color(0xFFFF6B6B)
}

/** Segmented horizontal storage bar (native Settings > Storage style). */
@Composable
fun StorageBar(
    segments: List<Pair<StorageCategory, Long>>,
    totalBytes: Long,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(14.dp)
            .clip(RoundedCornerShape(7.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        if (totalBytes <= 0) return@Row
        segments.forEach { (category, bytes) ->
            if (bytes <= 0) return@forEach
            val weight = (bytes.toFloat() / totalBytes.toFloat()).coerceIn(0.004f, 1f)
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .weight(weight)
                    .background(categoryColor(category)),
            )
        }
    }
}

/** A single MediaStore thumbnail (photo or video poster frame), loaded lazily via Coil. */
@Composable
fun MediaThumbnail(
    item: MediaItem,
    modifier: Modifier = Modifier,
    sizePx: Int = 300,
    contentScale: ContentScale = ContentScale.Crop,
) {
    Box(modifier = modifier) {
        AsyncImage(
            model = MediaThumbnailRequest(item.uri, sizePx),
            contentDescription = item.displayName,
            contentScale = contentScale,
            modifier = Modifier.fillMaxSize(),
        )
        if (item.mediaType == MediaType.VIDEO && item.durationMillis != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(4.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color.Black.copy(alpha = 0.65f))
                    .padding(horizontal = 5.dp, vertical = 2.dp),
            ) {
                Text(
                    text = formatDuration(item.durationMillis),
                    color = Color.White,
                    style = MaterialTheme.typography.labelSmall,
                )
            }
        }
    }
}

/** Grid thumbnail with a tappable multi-select checkmark overlay. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SelectableMediaThumbnail(
    item: MediaItem,
    isSelected: Boolean,
    onToggle: () -> Unit,
    onOpen: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(10.dp)),
    ) {
        MediaThumbnail(
            item = item,
            modifier = Modifier
                .fillMaxSize()
                .combinedClickable(onClick = onOpen, onLongClick = onToggle),
        )
        if (isSelected) {
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.35f)))
        }
        Icon(
            imageVector = if (isSelected) Icons.Filled.CheckCircle else Icons.Filled.Circle,
            contentDescription = if (isSelected) "Selected" else "Not selected",
            tint = if (isSelected) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.85f),
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(6.dp)
                .size(22.dp)
                .clip(CircleShape)
                .background(if (isSelected) Color.White else Color.Black.copy(alpha = 0.3f)),
        )
    }
}

@Composable
fun EmptyState(
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(
            imageVector = Icons.Filled.Inbox,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(48.dp),
        )
        androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(12.dp))
        Text(text = title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
        androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
    }
}

@Composable
fun LoadingIndicator(modifier: Modifier = Modifier, label: String? = null) {
    Column(
        modifier = modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
        if (label != null) {
            androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(12.dp))
            Text(text = label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/**
 * Launches a MediaStore system consent dialog (from createTrashRequest /
 * createDeleteRequest) whenever [pendingIntentSender] becomes non-null,
 * and reports the outcome back through [onResult]. Every screen that can
 * trigger a delete/trash/restore batch hosts one of these — see
 * data/DeleteRequestHelper.kt's PendingSystemAction for the queue this
 * drives.
 */
@Composable
fun SystemActionLauncherEffect(
    pendingIntentSender: IntentSender?,
    onResult: (confirmed: Boolean) -> Unit,
) {
    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult(),
    ) { result -> onResult(result.resultCode == Activity.RESULT_OK) }

    LaunchedEffect(pendingIntentSender) {
        pendingIntentSender?.let { sender ->
            launcher.launch(IntentSenderRequest.Builder(sender).build())
        }
    }
}
