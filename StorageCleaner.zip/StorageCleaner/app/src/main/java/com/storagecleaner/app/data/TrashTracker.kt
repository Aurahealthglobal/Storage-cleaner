package com.storagecleaner.app.data

import android.content.Context
import android.net.Uri
import org.json.JSONException
import org.json.JSONObject

/**
 * MediaStore's IS_TRASHED column is the source of truth for WHICH items
 * are trashed. Google's docs describe the OS's own auto-purge of trashed
 * items only as happening after a "system-defined time period" — not a
 * guaranteed number of days — so this class tracks WHEN this app trashed
 * each item, letting the Recently Deleted screen enforce a firm 7-day
 * promise regardless of what the OS itself decides to do.
 */
class TrashTracker(context: Context) {
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun recordTrashed(uris: List<Uri>, atEpochMillis: Long = System.currentTimeMillis()) {
        val current = readAll().toMutableMap()
        uris.forEach { current[it.toString()] = atEpochMillis }
        writeAll(current)
    }

    fun recordRemoved(uris: List<Uri>) {
        val current = readAll().toMutableMap()
        uris.forEach { current.remove(it.toString()) }
        writeAll(current)
    }

    fun trashedAtMillis(uri: Uri): Long? = readAll()[uri.toString()]

    /** URIs this app trashed 7+ days ago and hasn't heard restored — candidates for auto-purge. */
    fun expiredUris(nowMillis: Long = System.currentTimeMillis()): List<Uri> {
        val retentionMillis = RETENTION_DAYS * 86_400_000L
        return readAll()
            .filterValues { trashedAt -> nowMillis - trashedAt >= retentionMillis }
            .keys
            .map { Uri.parse(it) }
    }

    private fun readAll(): Map<String, Long> {
        val raw = prefs.getString(KEY_MAP, null) ?: return emptyMap()
        return try {
            val json = JSONObject(raw)
            json.keys().asSequence().associateWith { json.getLong(it) }
        } catch (e: JSONException) {
            emptyMap()
        }
    }

    private fun writeAll(map: Map<String, Long>) {
        val json = JSONObject()
        map.forEach { (k, v) -> json.put(k, v) }
        prefs.edit().putString(KEY_MAP, json.toString()).apply()
    }

    companion object {
        private const val PREFS_NAME = "storage_cleaner_trash_tracker"
        private const val KEY_MAP = "uri_to_trashed_at_millis"
        const val RETENTION_DAYS = 7
    }
}
