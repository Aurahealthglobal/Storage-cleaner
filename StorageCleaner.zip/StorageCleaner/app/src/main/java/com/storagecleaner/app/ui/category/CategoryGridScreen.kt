package com.storagecleaner.app.ui.category

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.SwipeLeft
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.storagecleaner.app.data.model.MediaItem
import com.storagecleaner.app.data.model.StorageCategory
import com.storagecleaner.app.ui.components.EmptyState
import com.storagecleaner.app.ui.components.LoadingIndicator
import com.storagecleaner.app.ui.components.SelectableMediaThumbnail
import com.storagecleaner.app.util.formatBytes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoryGridScreen(
    category: StorageCategory,
    viewModel: CategoryGridViewModel,
    onBack: () -> Unit,
    onDeleteSelected: (List<MediaItem>) -> Unit,
    onSwipeInstead: (List<MediaItem>) -> Unit,
) {
    LaunchedEffect(category) { viewModel.load(category) }
    val state by viewModel.uiState.collectAsState()
    val hasSelection = state.selectedIds.isNotEmpty()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(if (hasSelection) "${state.selectedIds.size} selected" else category.label)
                },
                navigationIcon = {
                    IconButton(onClick = if (hasSelection) viewModel::clearSelection else onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (state.items.isNotEmpty()) {
                        IconButton(onClick = viewModel::selectAll) {
                            Icon(Icons.Filled.DoneAll, contentDescription = "Select all")
                        }
                    }
                },
            )
        },
        bottomBar = {
            if (hasSelection) {
                Surface(tonalElevation = 3.dp) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Button(
                            onClick = { onDeleteSelected(state.selectedItems) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.error,
                            ),
                        ) {
                            Icon(Icons.Filled.Delete, contentDescription = null, modifier = Modifier.padding(end = 8.dp))
                            Text("Delete selected (${state.selectedIds.size} files, ${formatBytes(state.selectedBytes)})")
                        }
                    }
                }
            }
        },
    ) { padding ->
        when {
            state.isLoading -> LoadingIndicator(modifier = Modifier.padding(padding), label = "Loading ${category.label.lowercase()}…")
            state.items.isEmpty() -> EmptyState(
                modifier = Modifier.padding(padding),
                title = "Nothing here",
                subtitle = "No ${category.label.lowercase()} found on this device.",
            )
            else -> Column(modifier = Modifier.padding(padding)) {
                if (!hasSelection) {
                    OutlinedButton(
                        onClick = { onSwipeInstead(state.items) },
                        modifier = Modifier.fillMaxWidth().padding(16.dp, 12.dp, 16.dp, 0.dp),
                    ) {
                        Icon(Icons.Filled.SwipeLeft, contentDescription = null, modifier = Modifier.padding(end = 8.dp))
                        Text("Swipe review instead")
                    }
                }
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 100.dp),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    items(state.items, key = { it.id }) { item ->
                        SelectableMediaThumbnail(
                            item = item,
                            isSelected = item.id in state.selectedIds,
                            onToggle = { viewModel.toggleSelection(item) },
                            onOpen = { viewModel.toggleSelection(item) },
                        )
                    }
                }
            }
        }
    }
}
