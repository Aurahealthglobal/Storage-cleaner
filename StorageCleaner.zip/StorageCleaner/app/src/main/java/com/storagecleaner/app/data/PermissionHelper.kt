package com.storagecleaner.app.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

/**
 * Centralises the "which permission string, on which OS version" logic
 * that changed across API 30-34 (see README.md "Permissions across
 * Android versions" for what was verified and why).
 */
object PermissionHelper {

    /** The permission(s) to request at runtime, for the OS version this device is running. */
    fun requiredMediaPermissions(): Array<String> = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> arrayOf(
            Manifest.permission.READ_MEDIA_IMAGES,
            Manifest.permission.READ_MEDIA_VIDEO,
        )
        // API 30-32: no granular media permissions yet.
        else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    private fun granted(context: Context, permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    fun hasFullMediaAccess(context: Context): Boolean =
        requiredMediaPermissions().all { granted(context, it) }

    /** True on Android 14+ when the user chose "Select photos and videos" instead of "Allow all". */
    fun hasPartialMediaAccess(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE) return false
        val partial = granted(context, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
        return partial && !hasFullMediaAccess(context)
    }

    fun hasAnyMediaAccess(context: Context): Boolean =
        hasFullMediaAccess(context) || hasPartialMediaAccess(context)
}
