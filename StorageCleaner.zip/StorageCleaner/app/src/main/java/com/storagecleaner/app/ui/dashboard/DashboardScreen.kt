package com.storagecleaner.app.ui.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestoreFromTrash
import androidx.compose.material.icons.filled.SdCard
import androidx.compose.material.icons.filled.SwipeLeft
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.storagecleaner.app.data.model.CategoryBreakdown
import com.storagecleaner.app.data.model.MediaItem
import com.storagecleaner.app.data.model.StorageCategory
import com.storagecleaner.app.data.model.StorageVolumeInfo
import com.storagecleaner.app.ui.components.EmptyState
import com.storagecleaner.app.ui.components.LoadingIndicator
import com.storagecleaner.app.ui.components.StorageBar
import com.storagecleaner.app.ui.components.categoryColor
import com.storagecleaner.app.util.formatBytes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel,
    onOpenCategory: (StorageCategory) -> Unit,
    onStartSwipeReview: (List<MediaItem>) -> Unit,
    onOpenRecentlyDeleted: () -> Unit,
    onOpenSuggestions: () -> Unit,
) {
    val state by viewModel.uiState.collectAsState()

    // The dashboard's ViewModel is scoped to the back-stack entry, so
    // returning here after a delete (via popBackStack, not a fresh
    // composable instance) wouldn't otherwise pick up the new byte
    // counts — refresh on every resume, including the first one.
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) viewModel.refresh()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Storage Cleaner") },
                actions = {
                    IconButton(onClick = onOpenSuggestions) {
                        Icon(Icons.Filled.AutoAwesome, contentDescription = "Smart suggestions")
                    }
                    IconButton(onClick = onOpenRecentlyDeleted) {
                        Icon(Icons.Filled.RestoreFromTrash, contentDescription = "Recently deleted")
                    }
                    IconButton(onClick = { viewModel.refresh() }) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Refresh")
                    }
                },
            )
        },
    ) { padding ->
        when {
            state.isLoading && state.allMedia.isEmpty() -> LoadingIndicator(
                modifier = Modifier.padding(padding),
                label = "Scanning your library…",
            )
            state.errorMessage != null -> EmptyState(
                modifier = Modifier.padding(padding),
                title = "Something went wrong",
                subtitle = state.errorMessage.orEmpty(),
            )
            else -> DashboardContent(
                state = state,
                padding = padding,
                onOpenCategory = onOpenCategory,
                onStartSwipeReview = { onStartSwipeReview(state.allMedia) },
                onOpenSuggestions = onOpenSuggestions,
            )
        }
    }
}

@Composable
private fun DashboardContent(
    state: DashboardUiState,
    padding: androidx.compose.foundation.layout.PaddingValues,
    onOpenCategory: (StorageCategory) -> Unit,
    onStartSwipeReview: () -> Unit,
    onOpenSuggestions: () -> Unit,
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        items(state.volumes) { volume -> VolumeCard(volume) }

        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text("By category", style = MaterialTheme.typography.titleMedium)
                        Text(formatBytes(state.totalMediaBytes), style = MaterialTheme.typography.titleMedium)
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    StorageBar(
                        segments = state.breakdown.map { it.category to it.totalBytes },
                        totalBytes = state.totalMediaBytes,
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    state.breakdown
                        .filter { it.itemCount > 0 }
                        .sortedByDescending { it.totalBytes }
                        .forEach { breakdown -> CategoryRow(breakdown, onClick = { onOpenCategory(breakdown.category) }) }
                }
            }
        }

        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Filled.AutoAwesome,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp),
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Smart suggestions", style = MaterialTheme.typography.titleMedium)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (state.largeFileCount > 0) {
                            "${state.largeFileCount} large files using ${formatBytes(state.largeFileBytes)}. " +
                                "Scan for duplicate takes and old exports too."
                        } else {
                            "Scan for duplicate takes, old exports, and oversized files."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(onClick = onOpenSuggestions) { Text("Review suggestions") }
                }
            }
        }

        item {
            Button(
                onClick = onStartSwipeReview,
                modifier = Modifier.fillMaxWidth(),
                enabled = state.allMedia.isNotEmpty(),
            ) {
                Icon(Icons.Filled.SwipeLeft, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Quick swipe review — everything")
            }
        }
    }
}

@Composable
private fun VolumeCard(volume: StorageVolumeInfo) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (volume.isRemovable) Icons.Filled.SdCard else Icons.Filled.PhoneAndroid,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(volume.displayName, style = MaterialTheme.typography.titleMedium)
            }
            Spacer(modifier = Modifier.height(10.dp))
            val usedFraction = if (volume.totalBytes > 0) {
                (volume.usedBytes.toFloat() / volume.totalBytes.toFloat()).coerceIn(0f, 1f)
            } else {
                0f
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth(usedFraction)
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.primary),
                ) {}
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "${formatBytes(volume.freeBytes)} free of ${formatBytes(volume.totalBytes)}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun CategoryRow(breakdown: CategoryBreakdown, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Row(
            modifier = Modifier
                .size(10.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(categoryColor(breakdown.category)),
        ) {}
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(breakdown.category.label, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
            Text(
                "${breakdown.itemCount} items",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Text(formatBytes(breakdown.totalBytes), style = MaterialTheme.typography.bodyLarge)
        Icon(
            Icons.Filled.ChevronRight,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
