package com.storagecleaner.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Dark-first palette. Deliberately NOT using Material You dynamic color:
// this app leans on AccentKeep/AccentDelete as consistent, meaningful
// signal colors across the swipe review, grids, and confirmation screens
// — letting the wallpaper repaint those on every device would undercut
// that. See frontend-design notes in README.md.
val SurfaceDark = Color(0xFF0F1115)
val SurfaceContainerDark = Color(0xFF1A1D23)
val SurfaceVariantDark = Color(0xFF23262E)
val AccentKeep = Color(0xFF3DDC97) // swipe-right / "keep"
val AccentDelete = Color(0xFFFF6B6B) // swipe-left / "delete"
val AccentPrimary = Color(0xFF7C9CFF) // brand accent
val TextPrimaryDark = Color(0xFFECEDEF)
val TextSecondaryDark = Color(0xFFA0A4AC)

private val DarkColors = darkColorScheme(
    primary = AccentPrimary,
    onPrimary = Color(0xFF0B1030),
    secondary = AccentKeep,
    onSecondary = Color(0xFF00210F),
    tertiary = AccentDelete,
    error = AccentDelete,
    onError = Color(0xFF3A0A0A),
    background = SurfaceDark,
    onBackground = TextPrimaryDark,
    surface = SurfaceContainerDark,
    onSurface = TextPrimaryDark,
    surfaceVariant = SurfaceVariantDark,
    onSurfaceVariant = TextSecondaryDark,
    outline = Color(0xFF3A3E48),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF3355CC),
    secondary = Color(0xFF1E9E68),
    tertiary = Color(0xFFD03D3D),
    error = Color(0xFFD03D3D),
)

private val AppTypography = Typography(
    headlineMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 28.sp, lineHeight = 34.sp),
    titleLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 22.sp, lineHeight = 28.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 17.sp, lineHeight = 24.sp),
    bodyLarge = TextStyle(fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 20.sp),
)

@Composable
fun StorageCleanerTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AppTypography,
        content = content,
    )
}
