package com.storagecleaner.app.core

import android.content.Context
import com.storagecleaner.app.data.DeleteRequestHelper
import com.storagecleaner.app.data.DuplicateDetector
import com.storagecleaner.app.data.MediaRepository
import com.storagecleaner.app.data.SafRepository
import com.storagecleaner.app.data.TrashTracker

/**
 * Deliberately plain manual DI instead of Hilt/Koin: this app has a
 * handful of singletons and no multi-module graph, so a hand-written
 * container avoids pulling in an annotation-processing (KSP) dependency
 * that adds another thing that could fail to resolve/configure in an
 * environment this project hasn't been build-verified in. If the app
 * grows, migrating this to Hilt later is a mechanical change.
 */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    val mediaRepository: MediaRepository by lazy { MediaRepository(appContext) }
    val deleteRequestHelper: DeleteRequestHelper by lazy {
        DeleteRequestHelper(appContext.contentResolver)
    }
    val trashTracker: TrashTracker by lazy { TrashTracker(appContext) }
    val duplicateDetector: DuplicateDetector by lazy {
        DuplicateDetector(appContext.contentResolver)
    }
    val safRepository: SafRepository by lazy { SafRepository(appContext) }
}
