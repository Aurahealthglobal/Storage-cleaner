package com.storagecleaner.app.ui.shared

import androidx.lifecycle.ViewModel
import com.storagecleaner.app.core.AppContainer
import com.storagecleaner.app.data.model.MediaItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class PendingActionType { TRASH, PERMANENT_DELETE, RESTORE }

data class PendingAction(
    val items: List<MediaItem>,
    val type: PendingActionType,
    val title: String,
)

/**
 * Cross-screen hand-off state for the multi-step review/delete flow.
 * Compose Navigation doesn't pass large lists as nav arguments, so this
 * is created once where NavHost lives (see
 * ui/navigation/StorageCleanerNavHost.kt) and threaded into every screen
 * instead of being re-derived from a route string on each navigation.
 */
class SharedFlowViewModel(@Suppress("UNUSED_PARAMETER") container: AppContainer) : ViewModel() {

    private val _reviewQueue = MutableStateFlow<List<MediaItem>>(emptyList())
    val reviewQueue: StateFlow<List<MediaItem>> = _reviewQueue.asStateFlow()

    private val _pendingAction = MutableStateFlow<PendingAction?>(null)
    val pendingAction: StateFlow<PendingAction?> = _pendingAction.asStateFlow()

    /** Set by whichever screen launches swipe review: dashboard, a category grid, or suggestions. */
    fun setReviewQueue(items: List<MediaItem>) {
        _reviewQueue.value = items
    }

    fun stageAction(items: List<MediaItem>, type: PendingActionType, title: String) {
        _pendingAction.value = PendingAction(items, type, title)
    }

    fun clearPendingAction() {
        _pendingAction.value = null
    }
}
