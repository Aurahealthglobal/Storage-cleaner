package com.storagecleaner.app.ui.swipe

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.storagecleaner.app.data.model.MediaItem
import com.storagecleaner.app.ui.components.EmptyState
import com.storagecleaner.app.ui.components.MediaThumbnail
import com.storagecleaner.app.ui.theme.AccentDelete
import com.storagecleaner.app.ui.theme.AccentKeep
import com.storagecleaner.app.util.formatBytes
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SwipeReviewScreen(
    items: List<MediaItem>,
    viewModel: SwipeReviewViewModel,
    onBack: () -> Unit,
    onFinishReview: (List<MediaItem>) -> Unit,
) {
    LaunchedEffect(items) { viewModel.initialize(items) }
    val state by viewModel.uiState.collectAsState()

    LaunchedEffect(state.isComplete) {
        if (state.isComplete) onFinishReview(state.itemsMarkedForDelete)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Swipe review") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = viewModel::undoLast, enabled = state.decisions.isNotEmpty()) {
                        Icon(Icons.Filled.Undo, contentDescription = "Undo last swipe")
                    }
                },
            )
        },
    ) { padding ->
        when {
            items.isEmpty() -> EmptyState(
                modifier = Modifier.padding(padding),
                title = "Nothing to review",
                subtitle = "This selection is empty.",
            )
            state.isComplete -> Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            else -> Column(modifier = Modifier.fillMaxSize().padding(padding)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text("${state.currentIndex + 1} of ${state.queue.size}", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        "Will free ${formatBytes(state.bytesMarkedForDelete)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = AccentDelete,
                        fontWeight = FontWeight.Medium,
                    )
                }

                Box(
                    modifier = Modifier.weight(1f).fillMaxWidth().padding(20.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    state.nextItem?.let { next ->
                        Box(modifier = Modifier.fillMaxSize(0.94f).clip(RoundedCornerShape(24.dp))) {
                            MediaThumbnail(item = next, modifier = Modifier.fillMaxSize())
                        }
                    }
                    state.currentItem?.let { current ->
                        SwipeCard(key = current.id, item = current, onDecided = viewModel::swipe)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                ) {
                    FilledIconButton(
                        onClick = { viewModel.swipe(true) },
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = AccentDelete),
                        modifier = Modifier.size(64.dp),
                    ) {
                        Icon(Icons.Filled.Close, contentDescription = "Delete", tint = Color.White)
                    }
                    FilledIconButton(
                        onClick = { viewModel.swipe(false) },
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = AccentKeep),
                        modifier = Modifier.size(64.dp),
                    ) {
                        Icon(Icons.Filled.Check, contentDescription = "Keep", tint = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
private fun SwipeCard(key: Long, item: MediaItem, onDecided: (markForDelete: Boolean) -> Unit) {
    val scope = rememberCoroutineScope()
    val offsetX = remember(key) { Animatable(0f) }
    val offsetY = remember(key) { Animatable(0f) }
    val density = LocalDensity.current
    val flyDistancePx = with(density) { 1200.dp.toPx() }
    val swipeThresholdPx = with(density) { 120.dp.toPx() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer {
                translationX = offsetX.value
                translationY = offsetY.value
                rotationZ = (offsetX.value / 40f).coerceIn(-16f, 16f)
            }
            .pointerInput(key) {
                detectDragGestures(
                    onDrag = { change, dragAmount ->
                        change.consume()
                        scope.launch {
                            offsetX.snapTo(offsetX.value + dragAmount.x)
                            offsetY.snapTo(offsetY.value + dragAmount.y)
                        }
                    },
                    onDragEnd = {
                        val x = offsetX.value
                        when {
                            x > swipeThresholdPx -> scope.launch {
                                offsetX.animateTo(flyDistancePx, tween(250))
                                onDecided(false) // swiped right = keep
                            }
                            x < -swipeThresholdPx -> scope.launch {
                                offsetX.animateTo(-flyDistancePx, tween(250))
                                onDecided(true) // swiped left = delete
                            }
                            else -> scope.launch {
                                offsetX.animateTo(0f, tween(200))
                                offsetY.animateTo(0f, tween(200))
                            }
                        }
                    },
                )
            }
            .clip(RoundedCornerShape(24.dp)),
    ) {
        MediaThumbnail(item = item, modifier = Modifier.fillMaxSize())

        val dragX = offsetX.value
        if (dragX > 24f) {
            SwipeBadge(
                text = "KEEP",
                color = AccentKeep,
                alpha = (dragX / swipeThresholdPx).coerceIn(0f, 1f),
                modifier = Modifier.align(Alignment.TopStart),
            )
        } else if (dragX < -24f) {
            SwipeBadge(
                text = "DELETE",
                color = AccentDelete,
                alpha = (-dragX / swipeThresholdPx).coerceIn(0f, 1f),
                modifier = Modifier.align(Alignment.TopEnd),
            )
        }

        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .background(Color.Black.copy(alpha = 0.45f))
                .padding(12.dp),
        ) {
            Text(item.displayName, color = Color.White, style = MaterialTheme.typography.bodySmall, maxLines = 1)
        }
    }
}

@Composable
private fun SwipeBadge(text: String, color: Color, alpha: Float, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .padding(20.dp)
            .graphicsLayer { this.alpha = alpha }
            .clip(RoundedCornerShape(8.dp))
            .background(color)
            .padding(horizontal = 14.dp, vertical = 6.dp),
    ) {
        Text(text, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
    }
}
