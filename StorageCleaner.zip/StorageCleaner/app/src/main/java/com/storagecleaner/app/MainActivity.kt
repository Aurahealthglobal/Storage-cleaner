package com.storagecleaner.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.storagecleaner.app.core.AppContainer
import com.storagecleaner.app.data.PermissionHelper
import com.storagecleaner.app.ui.navigation.StorageCleanerNavHost
import com.storagecleaner.app.ui.permissions.PermissionGateScreen
import com.storagecleaner.app.ui.theme.StorageCleanerTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val container = (application as StorageCleanerApp).container
        setContent {
            StorageCleanerTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    StorageCleanerRoot(container)
                }
            }
        }
    }
}

/** Shows the permission gate until media access is granted, then the real app. */
@Composable
private fun StorageCleanerRoot(container: AppContainer) {
    val context = LocalContext.current
    var hasAccess by remember { mutableStateOf(PermissionHelper.hasAnyMediaAccess(context)) }

    if (hasAccess) {
        StorageCleanerNavHost(container)
    } else {
        PermissionGateScreen(
            onPermissionResult = { granted, partial -> hasAccess = granted || partial },
        )
    }
}
