package com.storagecleaner.app.core

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.CreationExtras

/**
 * One tiny factory for every ViewModel in the app: each ViewModel takes
 * an [AppContainer] as its only constructor argument and reads whatever
 * repositories it needs from it. Avoids writing a bespoke Factory class
 * per screen.
 */
class AppViewModelFactory(private val container: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>, extras: CreationExtras): T {
        return modelClass.getConstructor(AppContainer::class.java).newInstance(container)
    }
}
