package com.storagecleaner.app.ui.swipe

import androidx.lifecycle.ViewModel
import com.storagecleaner.app.core.AppContainer
import com.storagecleaner.app.data.model.MediaItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class SwipeDecision(val item: MediaItem, val markedForDelete: Boolean)

data class SwipeReviewUiState(
    val queue: List<MediaItem> = emptyList(),
    val currentIndex: Int = 0,
    val decisions: List<SwipeDecision> = emptyList(),
) {
    val currentItem: MediaItem? get() = queue.getOrNull(currentIndex)
    val nextItem: MediaItem? get() = queue.getOrNull(currentIndex + 1)
    val isComplete: Boolean get() = queue.isNotEmpty() && currentIndex >= queue.size
    val bytesMarkedForDelete: Long get() = decisions.filter { it.markedForDelete }.sumOf { it.item.sizeBytes }
    val itemsMarkedForDelete: List<MediaItem> get() = decisions.filter { it.markedForDelete }.map { it.item }
}

class SwipeReviewViewModel(@Suppress("UNUSED_PARAMETER") container: AppContainer) : ViewModel() {
    private val _uiState = MutableStateFlow(SwipeReviewUiState())
    val uiState: StateFlow<SwipeReviewUiState> = _uiState.asStateFlow()

    private var initialized = false

    /** Called once per review session — LaunchedEffect(items) on the screen guards re-entry. */
    fun initialize(items: List<MediaItem>) {
        if (initialized) return
        initialized = true
        _uiState.update { it.copy(queue = items) }
    }

    fun swipe(markForDelete: Boolean) {
        val current = _uiState.value.currentItem ?: return
        _uiState.update {
            it.copy(
                decisions = it.decisions + SwipeDecision(current, markForDelete),
                currentIndex = it.currentIndex + 1,
            )
        }
    }

    fun undoLast() {
        _uiState.update { state ->
            if (state.decisions.isEmpty()) return@update state
            state.copy(
                decisions = state.decisions.dropLast(1),
                currentIndex = (state.currentIndex - 1).coerceAtLeast(0),
            )
        }
    }
}
