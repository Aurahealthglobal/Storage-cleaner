package com.storagecleaner.app.ui.category

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.storagecleaner.app.core.AppContainer
import com.storagecleaner.app.data.MediaRepository
import com.storagecleaner.app.data.exclusiveCategory
import com.storagecleaner.app.data.model.MediaItem
import com.storagecleaner.app.data.model.StorageCategory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class CategoryGridUiState(
    val isLoading: Boolean = true,
    val category: StorageCategory? = null,
    val items: List<MediaItem> = emptyList(),
    val selectedIds: Set<Long> = emptySet(),
) {
    val selectedItems: List<MediaItem> get() = items.filter { it.id in selectedIds }
    val selectedBytes: Long get() = selectedItems.sumOf { it.sizeBytes }
}

class CategoryGridViewModel(container: AppContainer) : ViewModel() {
    private val repository: MediaRepository = container.mediaRepository

    private val _uiState = MutableStateFlow(CategoryGridUiState())
    val uiState: StateFlow<CategoryGridUiState> = _uiState.asStateFlow()

    private var loadedCategory: StorageCategory? = null

    fun load(category: StorageCategory) {
        if (loadedCategory == category) return
        loadedCategory = category
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, category = category) }
            val allMedia = repository.queryMedia()
            // LARGE_FILES is a cross-cutting filter (a large file is still a Photo/Video),
            // so it isn't part of exclusiveCategory()'s partition — handled separately here.
            // DUPLICATES needs a prior scan and its own group-aware UI; see Smart Suggestions.
            val filtered = when (category) {
                StorageCategory.LARGE_FILES -> allMedia.filter { it.isLarge }
                StorageCategory.DUPLICATES -> emptyList()
                else -> allMedia.filter { it.exclusiveCategory() == category }
            }.sortedByDescending { it.sizeBytes }
            _uiState.update { it.copy(isLoading = false, items = filtered, selectedIds = emptySet()) }
        }
    }

    fun toggleSelection(item: MediaItem) {
        _uiState.update { state ->
            val newSelection = if (item.id in state.selectedIds) state.selectedIds - item.id else state.selectedIds + item.id
            state.copy(selectedIds = newSelection)
        }
    }

    fun selectAll() {
        _uiState.update { it.copy(selectedIds = it.items.map { item -> item.id }.toSet()) }
    }

    fun clearSelection() {
        _uiState.update { it.copy(selectedIds = emptySet()) }
    }
}
