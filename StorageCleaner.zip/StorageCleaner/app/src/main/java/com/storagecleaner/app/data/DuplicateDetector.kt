package com.storagecleaner.app.data

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.storagecleaner.app.data.model.DuplicateGroup
import com.storagecleaner.app.data.model.MediaItem
import com.storagecleaner.app.data.model.MediaType
import com.storagecleaner.app.util.withinTolerance
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs

/**
 * Finds likely duplicate/near-duplicate photos and videos without any ML
 * model, per the brief:
 *  - Photos: a classic 8x8 average hash (aHash) — downscale to greyscale,
 *    threshold against the mean, compare Hamming distance between 64-bit
 *    hashes. Cheap, fully offline, and the standard approach for
 *    near-duplicate photo detection.
 *  - Videos: hashing every frame is expensive and unnecessary for what
 *    creators actually hit — a few raw takes of the same shot recorded
 *    seconds apart. Clustering by (duration, file size, creation-time
 *    proximity) catches that pattern without decoding any video.
 *
 * Runs on Dispatchers.Default as an explicit, user-triggered scan (see
 * SmartSuggestionsViewModel) rather than automatically — hashing
 * thousands of photos takes real time; see README.md "Performance notes".
 */
class DuplicateDetector(private val resolver: ContentResolver) {

    suspend fun findPhotoDuplicates(
        photos: List<MediaItem>,
        hammingThreshold: Int = 6,
    ): List<DuplicateGroup> = withContext(Dispatchers.Default) {
        val hashes = photos.mapNotNull { item -> averageHash(item)?.let { item to it } }
        val used = HashSet<Long>()
        val groups = mutableListOf<DuplicateGroup>()

        for (i in hashes.indices) {
            val (item, hash) = hashes[i]
            if (item.id in used) continue
            val cluster = mutableListOf(item)
            for (j in i + 1 until hashes.size) {
                val (otherItem, otherHash) = hashes[j]
                if (otherItem.id in used) continue
                if (hammingDistance(hash, otherHash) <= hammingThreshold) {
                    cluster += otherItem
                    used += otherItem.id
                }
            }
            if (cluster.size > 1) {
                used += item.id
                groups += DuplicateGroup(
                    id = "photo-${item.id}",
                    items = cluster.sortedByDescending { it.sizeBytes },
                    reason = "Visually similar images",
                )
            }
        }
        groups
    }

    suspend fun findVideoClusters(
        videos: List<MediaItem>,
        maxCreationGapSeconds: Long = 120,
        sizeTolerancePercent: Double = 0.15,
    ): List<DuplicateGroup> = withContext(Dispatchers.Default) {
        val sorted = videos.sortedBy { it.dateAddedEpochSeconds }
        val used = HashSet<Long>()
        val groups = mutableListOf<DuplicateGroup>()

        for (i in sorted.indices) {
            val item = sorted[i]
            if (item.id in used) continue
            val cluster = mutableListOf(item)
            for (j in i + 1 until sorted.size) {
                val other = sorted[j]
                if (other.id in used) continue
                val gap = abs(other.dateAddedEpochSeconds - item.dateAddedEpochSeconds)
                if (gap > maxCreationGapSeconds) break // sorted by time — nothing further can match
                val sameDuration = item.durationMillis != null && other.durationMillis != null &&
                    abs(item.durationMillis - other.durationMillis) < 1500
                val sizeClose = withinTolerance(item.sizeBytes, other.sizeBytes, sizeTolerancePercent)
                if (sameDuration && sizeClose) {
                    cluster += other
                    used += other.id
                }
            }
            if (cluster.size > 1) {
                used += item.id
                groups += DuplicateGroup(
                    id = "video-${item.id}",
                    items = cluster.sortedByDescending { it.sizeBytes },
                    reason = "Similar length & size, recorded moments apart — likely repeat takes",
                )
            }
        }
        groups
    }

    /** 64-bit average hash: 8x8 greyscale thumbnail, 1 bit per pixel vs. the mean. */
    private fun averageHash(item: MediaItem): Long? {
        if (item.mediaType != MediaType.IMAGE) return null
        val bitmap = decodeTinyBitmap(item) ?: return null
        val pixels = IntArray(64)
        bitmap.getPixels(pixels, 0, 8, 0, 0, 8, 8)
        bitmap.recycle()
        val greys = pixels.map { pixel ->
            val r = (pixel shr 16) and 0xFF
            val g = (pixel shr 8) and 0xFF
            val b = pixel and 0xFF
            (r + g + b) / 3
        }
        val mean = greys.average()
        var hash = 0L
        greys.forEachIndexed { index, value -> if (value >= mean) hash = hash or (1L shl index) }
        return hash
    }

    private fun decodeTinyBitmap(item: MediaItem): Bitmap? = try {
        resolver.openInputStream(item.uri)?.use { stream ->
            val options = BitmapFactory.Options().apply { inSampleSize = 16 }
            val sampled = BitmapFactory.decodeStream(stream, null, options)
            sampled?.let {
                val scaled = Bitmap.createScaledBitmap(it, 8, 8, true)
                if (scaled !== it) it.recycle()
                scaled
            }
        }
    } catch (e: Exception) {
        null
    }

    private fun hammingDistance(a: Long, b: Long): Int = java.lang.Long.bitCount(a xor b)
}
