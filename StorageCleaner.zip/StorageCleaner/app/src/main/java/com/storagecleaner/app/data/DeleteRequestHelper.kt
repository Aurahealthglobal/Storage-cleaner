package com.storagecleaner.app.data

import android.app.PendingIntent
import android.content.ContentResolver
import android.content.IntentSender
import android.net.Uri
import android.provider.MediaStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Builds MediaStore's batched consent-dialog requests. Both
 * createTrashRequest() and createDeleteRequest() show ONE system
 * confirmation for the whole list passed in — this is what gives the
 * "one dialog per batch, not per file" behaviour, as long as callers
 * pass the whole selection in a single list (which every screen here
 * does; see ui/*/*ViewModel.kt).
 *
 * Google's docs note a 2000-URI cap per request on the newest targeted
 * SDKs, so batches are chunked defensively even though a phone gallery
 * selection is very unlikely to ever hit that.
 */
class DeleteRequestHelper(private val resolver: ContentResolver) {

    private val maxUrisPerRequest = 2000

    /** Moves [uris] into the MediaStore trash (recoverable) — swipe/grid "delete". */
    fun trashRequests(uris: List<Uri>): List<PendingIntent> =
        uris.chunked(maxUrisPerRequest).map { chunk ->
            MediaStore.createTrashRequest(resolver, chunk, true)
        }

    /** Restores previously trashed [uris] — Recently Deleted "restore". */
    fun untrashRequests(uris: List<Uri>): List<PendingIntent> =
        uris.chunked(maxUrisPerRequest).map { chunk ->
            MediaStore.createTrashRequest(resolver, chunk, false)
        }

    /** Permanently deletes [uris] — emptying the trash, or the 7-day auto-purge. */
    fun deleteRequests(uris: List<Uri>): List<PendingIntent> =
        uris.chunked(maxUrisPerRequest).map { chunk ->
            MediaStore.createDeleteRequest(resolver, chunk)
        }
}

/**
 * Drives a sequence of system consent dialogs one at a time from a
 * ViewModel, without the ViewModel needing to hold an
 * ActivityResultLauncher (only a Composable/Activity can host one).
 *
 * Usage: call [start] with a batch of PendingIntents, expose
 * [currentIntentSender] to the screen (launch it with
 * rememberLauncherForActivityResult), and report each result back via
 * [onDialogResult]. [onBatchFinished] fires once, after the whole batch
 * completes or the user declines any dialog in it.
 */
class PendingSystemAction(
    private val onBatchFinished: (allConfirmed: Boolean) -> Unit,
) {
    private var queue: MutableList<PendingIntent> = mutableListOf()

    private val _currentIntentSender = MutableStateFlow<IntentSender?>(null)
    val currentIntentSender: StateFlow<IntentSender?> = _currentIntentSender.asStateFlow()

    fun start(pendingIntents: List<PendingIntent>) {
        if (pendingIntents.isEmpty()) {
            onBatchFinished(true)
            return
        }
        queue = pendingIntents.toMutableList()
        dispatchNext()
    }

    fun onDialogResult(confirmed: Boolean) {
        _currentIntentSender.value = null
        if (!confirmed) {
            queue.clear()
            onBatchFinished(false)
            return
        }
        dispatchNext()
    }

    private fun dispatchNext() {
        val next = queue.removeFirstOrNull()
        if (next == null) {
            onBatchFinished(true)
            return
        }
        _currentIntentSender.value = next.intentSender
    }
}
