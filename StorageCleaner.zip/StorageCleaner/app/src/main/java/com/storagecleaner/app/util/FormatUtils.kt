package com.storagecleaner.app.util

import com.storagecleaner.app.data.TrashTracker
import java.text.CharacterIterator
import java.text.StringCharacterIterator
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.abs

/** Human-readable byte size, e.g. 1536000L -> "1.5 MB". */
fun formatBytes(bytes: Long): String {
    var value = bytes
    if (-1000 < value && value < 1000) return "$value B"
    val ci: CharacterIterator = StringCharacterIterator("kMGTPE")
    while (value <= -999_950 || value >= 999_950) {
        value /= 1000
        ci.next()
    }
    return String.format("%.1f %cB", value / 1000.0, ci.current())
}

/** e.g. "Aug 14, 2026". */
fun formatDate(epochSeconds: Long): String {
    val formatter = DateTimeFormatter.ofPattern("MMM d, yyyy")
    return Instant.ofEpochSecond(epochSeconds).atZone(ZoneId.systemDefault()).format(formatter)
}

fun daysSince(epochSeconds: Long, nowEpochSeconds: Long = Instant.now().epochSecond): Int =
    ((nowEpochSeconds - epochSeconds) / 86_400).toInt()

/** Days left before this app auto-purges a trashed item; null if unknown (e.g. trashed by another app). */
fun daysRemainingInTrash(trashedAtMillis: Long?, nowMillis: Long = System.currentTimeMillis()): Int? {
    if (trashedAtMillis == null) return null
    val elapsedDays = ((nowMillis - trashedAtMillis) / 86_400_000L).toInt()
    return (TrashTracker.RETENTION_DAYS - elapsedDays).coerceAtLeast(0)
}

/** e.g. 75_000L -> "1:15". */
fun formatDuration(millis: Long): String {
    val totalSeconds = millis / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format("%d:%02d", minutes, seconds)
}

/** True if two byte sizes are within [tolerancePercent] of each other. */
fun withinTolerance(a: Long, b: Long, tolerancePercent: Double): Boolean {
    if (a == 0L && b == 0L) return true
    val larger = maxOf(a, b).toDouble()
    return abs(a - b).toDouble() / larger <= tolerancePercent
}
