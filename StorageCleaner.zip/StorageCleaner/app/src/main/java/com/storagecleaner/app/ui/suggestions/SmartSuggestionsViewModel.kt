package com.storagecleaner.app.ui.suggestions

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.storagecleaner.app.core.AppContainer
import com.storagecleaner.app.data.DuplicateDetector
import com.storagecleaner.app.data.MediaRepository
import com.storagecleaner.app.data.isFromEditorApp
import com.storagecleaner.app.data.isOldExport
import com.storagecleaner.app.data.isScreenshot
import com.storagecleaner.app.data.model.DuplicateGroup
import com.storagecleaner.app.data.model.MediaItem
import com.storagecleaner.app.data.model.MediaType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SuggestionSection(
    val title: String,
    val subtitle: String,
    val items: List<MediaItem>,
) {
    val totalBytes: Long get() = items.sumOf { it.sizeBytes }
}

data class SmartSuggestionsUiState(
    val isLoading: Boolean = true,
    val isScanningDuplicates: Boolean = false,
    val hasScannedDuplicates: Boolean = false,
    val largeFiles: SuggestionSection = SuggestionSection("Large files", "Over 50MB", emptyList()),
    val oldExports: SuggestionSection = SuggestionSection("Old exports", "Videos older than 30 days", emptyList()),
    val oldScreenshots: SuggestionSection = SuggestionSection("Old screenshots", "Screenshots older than 14 days", emptyList()),
    val editorFiles: SuggestionSection = SuggestionSection("Editing app files", "In CapCut/InShot/etc. export folders", emptyList()),
    val duplicatePhotoGroups: List<DuplicateGroup> = emptyList(),
    val duplicateVideoGroups: List<DuplicateGroup> = emptyList(),
) {
    val duplicateGroups: List<DuplicateGroup> get() = duplicatePhotoGroups + duplicateVideoGroups
    val duplicateReclaimableBytes: Long get() = duplicateGroups.sumOf { it.reclaimableBytes }
    val duplicateExtraItems: List<MediaItem> get() = duplicateGroups.flatMap { it.items.drop(1) }
}

class SmartSuggestionsViewModel(container: AppContainer) : ViewModel() {
    private val repository: MediaRepository = container.mediaRepository
    private val duplicateDetector: DuplicateDetector = container.duplicateDetector

    private val _uiState = MutableStateFlow(SmartSuggestionsUiState())
    val uiState: StateFlow<SmartSuggestionsUiState> = _uiState.asStateFlow()

    private var cachedMedia: List<MediaItem> = emptyList()

    init {
        loadQuickScans()
    }

    private fun loadQuickScans() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val media = repository.queryMedia()
            cachedMedia = media

            val nowSeconds = System.currentTimeMillis() / 1000
            val large = media.filter { it.isLarge }.sortedByDescending { it.sizeBytes }
            val oldExports = media.filter { it.isOldExport() }.sortedBy { it.dateAddedEpochSeconds }
            val oldScreenshots = media.filter { item ->
                item.isScreenshot() && (nowSeconds - item.dateAddedEpochSeconds) / 86_400 >= 14
            }.sortedBy { it.dateAddedEpochSeconds }
            val editorFiles = media.filter { it.isFromEditorApp() }
                .sortedByDescending { it.sizeBytes }

            _uiState.update {
                it.copy(
                    isLoading = false,
                    largeFiles = it.largeFiles.copy(items = large),
                    oldExports = it.oldExports.copy(items = oldExports),
                    oldScreenshots = it.oldScreenshots.copy(items = oldScreenshots),
                    editorFiles = it.editorFiles.copy(items = editorFiles),
                )
            }
        }
    }

    fun scanForDuplicates() {
        if (_uiState.value.isScanningDuplicates) return
        viewModelScope.launch {
            _uiState.update { it.copy(isScanningDuplicates = true) }
            val photos = cachedMedia.filter { it.mediaType == MediaType.IMAGE }
            val videos = cachedMedia.filter { it.mediaType == MediaType.VIDEO }
            val photoGroups = duplicateDetector.findPhotoDuplicates(photos)
            val videoGroups = duplicateDetector.findVideoClusters(videos)
            _uiState.update {
                it.copy(
                    isScanningDuplicates = false,
                    hasScannedDuplicates = true,
                    duplicatePhotoGroups = photoGroups,
                    duplicateVideoGroups = videoGroups,
                )
            }
        }
    }
}
