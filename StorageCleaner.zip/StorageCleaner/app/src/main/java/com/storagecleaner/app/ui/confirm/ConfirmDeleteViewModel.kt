package com.storagecleaner.app.ui.confirm

import android.content.IntentSender
import androidx.lifecycle.ViewModel
import com.storagecleaner.app.core.AppContainer
import com.storagecleaner.app.data.DeleteRequestHelper
import com.storagecleaner.app.data.PendingSystemAction
import com.storagecleaner.app.data.TrashTracker
import com.storagecleaner.app.ui.shared.PendingAction
import com.storagecleaner.app.ui.shared.PendingActionType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class ConfirmUiState(
    val isProcessing: Boolean = false,
    val isDone: Boolean = false,
    val wasCancelled: Boolean = false,
)

class ConfirmDeleteViewModel(container: AppContainer) : ViewModel() {
    private val deleteRequestHelper: DeleteRequestHelper = container.deleteRequestHelper
    private val trashTracker: TrashTracker = container.trashTracker

    private val _uiState = MutableStateFlow(ConfirmUiState())
    val uiState: StateFlow<ConfirmUiState> = _uiState.asStateFlow()

    private var actionInFlight: PendingAction? = null

    private val pendingSystemAction = PendingSystemAction { allConfirmed ->
        val action = actionInFlight
        if (allConfirmed && action != null) {
            val uris = action.items.map { it.uri }
            when (action.type) {
                PendingActionType.TRASH -> trashTracker.recordTrashed(uris)
                PendingActionType.RESTORE -> trashTracker.recordRemoved(uris)
                PendingActionType.PERMANENT_DELETE -> trashTracker.recordRemoved(uris)
            }
        }
        _uiState.update { it.copy(isProcessing = false, isDone = allConfirmed, wasCancelled = !allConfirmed) }
    }
    val currentIntentSender: StateFlow<IntentSender?> = pendingSystemAction.currentIntentSender

    fun confirm(action: PendingAction) {
        actionInFlight = action
        _uiState.update { it.copy(isProcessing = true) }
        val uris = action.items.map { it.uri }
        val requests = when (action.type) {
            PendingActionType.TRASH -> deleteRequestHelper.trashRequests(uris)
            PendingActionType.RESTORE -> deleteRequestHelper.untrashRequests(uris)
            PendingActionType.PERMANENT_DELETE -> deleteRequestHelper.deleteRequests(uris)
        }
        pendingSystemAction.start(requests)
    }

    fun onDialogResult(confirmed: Boolean) {
        pendingSystemAction.onDialogResult(confirmed)
    }
}
