package com.storagecleaner.app.data

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.documentfile.provider.DocumentFile

/**
 * Storage Access Framework access for content MediaStore doesn't cover —
 * mainly non-media files (project files, .tmp/.draft leftovers) on an SD
 * card, reached only inside a folder tree the user explicitly picks via
 * the system folder picker (ACTION_OPEN_DOCUMENT_TREE, wired up in
 * ui/suggestions/SmartSuggestionsScreen.kt).
 *
 * This is the deliberate, Play-policy-friendly alternative to
 * MANAGE_EXTERNAL_STORAGE: access is scoped to exactly the tree the user
 * chose, nothing broader — see README.md "Why there's no 'deep scan'
 * permission".
 */
class SafRepository(private val context: Context) {
    private val resolver: ContentResolver get() = context.contentResolver

    fun persistedTreeUris(): List<Uri> = resolver.persistedUriPermissions
        .filter { it.isReadPermission }
        .map { it.uri }

    fun persistGrant(treeUri: Uri) {
        resolver.takePersistableUriPermission(
            treeUri,
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
        )
    }

    fun releaseGrant(treeUri: Uri) {
        try {
            resolver.releasePersistableUriPermission(
                treeUri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
            )
        } catch (e: SecurityException) {
            // Already released, or never held — safe to ignore.
        }
    }

    /** Lists files under [treeUri], recursing into sub-folders. */
    fun listFiles(treeUri: Uri): List<SafFile> {
        val root = DocumentFile.fromTreeUri(context, treeUri) ?: return emptyList()
        val results = mutableListOf<SafFile>()
        fun walk(dir: DocumentFile) {
            dir.listFiles().forEach { doc ->
                if (doc.isDirectory) {
                    walk(doc)
                } else {
                    results += SafFile(
                        uri = doc.uri,
                        name = doc.name ?: "unknown",
                        sizeBytes = doc.length(),
                        lastModifiedMillis = doc.lastModified(),
                    )
                }
            }
        }
        walk(root)
        return results
    }

    fun delete(fileUri: Uri): Boolean = DocumentFile.fromSingleUri(context, fileUri)?.delete() ?: false
}

data class SafFile(
    val uri: Uri,
    val name: String,
    val sizeBytes: Long,
    val lastModifiedMillis: Long,
)
