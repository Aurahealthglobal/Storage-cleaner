package com.storagecleaner.app.data

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.storage.StorageManager
import android.provider.MediaStore
import com.storagecleaner.app.data.model.MediaItem
import com.storagecleaner.app.data.model.MediaType
import com.storagecleaner.app.data.model.StorageCategory
import com.storagecleaner.app.data.model.StorageVolumeInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * All MediaStore access lives here. Deliberately query-based (never a raw
 * file-tree walk) so it stays fast with thousands of files — see
 * README.md "Why MediaStore, not file-tree walks".
 */
class MediaRepository(private val context: Context) {

    private val resolver: ContentResolver get() = context.contentResolver

    // ---------------------------------------------------------------
    // Storage volumes (internal vs. removable SD card)
    // ---------------------------------------------------------------

    suspend fun getStorageVolumes(): List<StorageVolumeInfo> = withContext(Dispatchers.IO) {
        val storageManager = context.getSystemService(Context.STORAGE_SERVICE) as StorageManager
        val mediaStoreVolumeNames = MediaStore.getExternalVolumeNames(context)
        storageManager.storageVolumes.mapNotNull { volume ->
            if (volume.state != Environment.MEDIA_MOUNTED) return@mapNotNull null
            val dir = volume.directory ?: return@mapNotNull null
            val msName = volume.mediaStoreVolumeName ?: return@mapNotNull null
            if (msName !in mediaStoreVolumeNames) return@mapNotNull null
            StorageVolumeInfo(
                volumeName = msName,
                displayName = volume.getDescription(context)
                    ?: if (volume.isPrimary) "Internal storage" else "SD card",
                isRemovable = volume.isRemovable,
                totalBytes = dir.totalSpace,
                freeBytes = dir.freeSpace,
            )
        }
    }

    // ---------------------------------------------------------------
    // Media queries
    // ---------------------------------------------------------------

    /** All photos + videos across every mounted volume. Excludes trashed items. */
    suspend fun queryMedia(): List<MediaItem> = withContext(Dispatchers.IO) {
        queryAllVolumes(trashedOnly = false)
    }

    /** Only items currently in the MediaStore trash, across every volume. */
    suspend fun queryTrashed(): List<MediaItem> = withContext(Dispatchers.IO) {
        queryAllVolumes(trashedOnly = true)
    }

    private fun queryAllVolumes(trashedOnly: Boolean): List<MediaItem> {
        val volumeNames = MediaStore.getExternalVolumeNames(context)
        return volumeNames.flatMap { volumeName ->
            queryCollection(volumeName, MediaType.IMAGE, trashedOnly) +
                queryCollection(volumeName, MediaType.VIDEO, trashedOnly)
        }
    }

    private fun queryCollection(
        volumeName: String,
        mediaType: MediaType,
        trashedOnly: Boolean,
    ): List<MediaItem> {
        val collectionUri = when (mediaType) {
            MediaType.IMAGE -> MediaStore.Images.Media.getContentUri(volumeName)
            MediaType.VIDEO -> MediaStore.Video.Media.getContentUri(volumeName)
        } ?: return emptyList()

        val projection = buildList {
            add(MediaStore.MediaColumns._ID)
            add(MediaStore.MediaColumns.DISPLAY_NAME)
            add(MediaStore.MediaColumns.SIZE)
            add(MediaStore.MediaColumns.DATE_ADDED)
            add(MediaStore.MediaColumns.DATE_MODIFIED)
            add(MediaStore.MediaColumns.WIDTH)
            add(MediaStore.MediaColumns.HEIGHT)
            add(MediaStore.MediaColumns.RELATIVE_PATH)
            add(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME)
            add(MediaStore.MediaColumns.IS_TRASHED)
            if (mediaType == MediaType.VIDEO) add(MediaStore.Video.VideoColumns.DURATION)
        }.toTypedArray()

        val queryArgs = Bundle().apply {
            putInt(
                MediaStore.QUERY_ARG_MATCH_TRASHED,
                if (trashedOnly) MediaStore.MATCH_ONLY else MediaStore.MATCH_EXCLUDE,
            )
            putString(
                ContentResolver.QUERY_ARG_SQL_SORT_ORDER,
                "${MediaStore.MediaColumns.DATE_ADDED} DESC",
            )
        }

        val items = mutableListOf<MediaItem>()
        try {
            resolver.query(collectionUri, projection, queryArgs, null)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                val addedCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                val modifiedCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)
                val widthCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.WIDTH)
                val heightCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.HEIGHT)
                val pathCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.RELATIVE_PATH)
                val bucketCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME)
                val trashedCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.IS_TRASHED)
                val durationCol = if (mediaType == MediaType.VIDEO) {
                    cursor.getColumnIndex(MediaStore.Video.VideoColumns.DURATION)
                } else {
                    -1
                }

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    items += MediaItem(
                        id = id,
                        uri = ContentUris.withAppendedId(collectionUri, id),
                        displayName = cursor.getString(nameCol) ?: "",
                        mediaType = mediaType,
                        sizeBytes = cursor.getLong(sizeCol),
                        dateAddedEpochSeconds = cursor.getLong(addedCol),
                        dateModifiedEpochSeconds = cursor.getLong(modifiedCol),
                        durationMillis = if (durationCol >= 0) cursor.getLong(durationCol) else null,
                        widthPx = cursor.getInt(widthCol),
                        heightPx = cursor.getInt(heightCol),
                        relativePath = cursor.getString(pathCol) ?: "",
                        bucketName = cursor.getString(bucketCol) ?: "",
                        volumeName = volumeName,
                        isOnRemovableVolume = volumeName != MediaStore.VOLUME_EXTERNAL_PRIMARY,
                        isTrashed = cursor.getInt(trashedCol) != 0,
                    )
                }
            }
        } catch (e: SecurityException) {
            // Permission revoked mid-session (e.g. partial-access grant
            // changed) — surface as "nothing found" rather than crashing;
            // the permission-gate screen re-checks on next resume.
        }
        return items
    }
}

// ---------------------------------------------------------------------
// Category classification — pure functions over MediaItem metadata.
// Each item gets exactly ONE "exclusiveCategory" so the dashboard's
// stacked bar sums to the real total without double-counting bytes.
// Large Files and Duplicates are cross-cutting (a large file is also a
// Photo or a Video) so they're surfaced as separate callouts instead of
// bar segments — see README.md "Why categories don't all live in one bar".
// ---------------------------------------------------------------------

private val messagingFolderMarkers = listOf("WhatsApp", "Telegram")

// MediaStore-visible export/project folder names for common creator apps.
// This is a best-effort, name-pattern match against PUBLIC folders
// (DCIM/Movies/Pictures) — it is NOT reading any app's private cache.
// See README.md "What 'Editing App Files' actually scans".
private val editorFolderMarkers = listOf(
    "CapCut", "InShot", "VN", "VivaVideo", "KineMaster", "Filmora",
    "Premiere Rush", "PremiereRush", "PowerDirector", "Alight Motion",
    "LumaFusion", "VLLO",
)

fun MediaItem.isScreenshot(): Boolean =
    bucketName.contains("Screenshot", ignoreCase = true) ||
        relativePath.contains("Screenshot", ignoreCase = true) ||
        displayName.contains("Screenshot", ignoreCase = true)

fun MediaItem.isFromMessagingApp(): Boolean =
    messagingFolderMarkers.any { relativePath.contains(it, ignoreCase = true) }

fun MediaItem.isFromEditorApp(): Boolean =
    editorFolderMarkers.any { marker ->
        relativePath.contains(marker, ignoreCase = true) || bucketName.contains(marker, ignoreCase = true)
    }

fun MediaItem.isInDownloads(): Boolean = relativePath.contains("Download", ignoreCase = true)

fun MediaItem.isOldExport(nowEpochSeconds: Long = System.currentTimeMillis() / 1000): Boolean {
    val ageDays = (nowEpochSeconds - dateAddedEpochSeconds) / 86_400
    return mediaType == MediaType.VIDEO && ageDays >= MediaItem.OLD_EXPORT_THRESHOLD_DAYS &&
        !isFromMessagingApp()
}

/** Exactly one category per item — see file header. [duplicateIds] comes from a Smart Suggestions scan. */
fun MediaItem.exclusiveCategory(duplicateIds: Set<Long> = emptySet()): StorageCategory = when {
    id in duplicateIds -> StorageCategory.DUPLICATES
    isFromMessagingApp() -> StorageCategory.MESSAGING_MEDIA
    isFromEditorApp() -> StorageCategory.EDITOR_FILES
    isInDownloads() -> StorageCategory.DOWNLOADS
    isScreenshot() -> StorageCategory.SCREENSHOTS
    mediaType == MediaType.IMAGE -> StorageCategory.PHOTOS
    else -> StorageCategory.VIDEOS
}
