package com.storagecleaner.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.storagecleaner.app.core.AppContainer
import com.storagecleaner.app.core.AppViewModelFactory
import com.storagecleaner.app.data.model.StorageCategory
import com.storagecleaner.app.ui.category.CategoryGridScreen
import com.storagecleaner.app.ui.category.CategoryGridViewModel
import com.storagecleaner.app.ui.confirm.ConfirmDeleteScreen
import com.storagecleaner.app.ui.confirm.ConfirmDeleteViewModel
import com.storagecleaner.app.ui.dashboard.DashboardScreen
import com.storagecleaner.app.ui.dashboard.DashboardViewModel
import com.storagecleaner.app.ui.recentlydeleted.RecentlyDeletedScreen
import com.storagecleaner.app.ui.recentlydeleted.RecentlyDeletedViewModel
import com.storagecleaner.app.ui.shared.PendingActionType
import com.storagecleaner.app.ui.shared.SharedFlowViewModel
import com.storagecleaner.app.ui.suggestions.SmartSuggestionsScreen
import com.storagecleaner.app.ui.suggestions.SmartSuggestionsViewModel
import com.storagecleaner.app.ui.swipe.SwipeReviewScreen
import com.storagecleaner.app.ui.swipe.SwipeReviewViewModel
import com.storagecleaner.app.util.formatBytes

private object Routes {
    const val DASHBOARD = "dashboard"
    const val CATEGORY = "category/{category}"
    const val SWIPE = "swipe"
    const val CONFIRM = "confirm"
    const val RECENTLY_DELETED = "recently_deleted"
    const val SUGGESTIONS = "suggestions"

    fun category(category: StorageCategory) = "category/${category.name}"
}

@Composable
fun StorageCleanerNavHost(container: AppContainer) {
    val navController = rememberNavController()
    val factory = remember { AppViewModelFactory(container) }
    val sharedFlowViewModel: SharedFlowViewModel = viewModel(factory = factory)

    NavHost(navController = navController, startDestination = Routes.DASHBOARD) {

        composable(Routes.DASHBOARD) {
            val vm: DashboardViewModel = viewModel(factory = factory)
            DashboardScreen(
                viewModel = vm,
                onOpenCategory = { category -> navController.navigate(Routes.category(category)) },
                onStartSwipeReview = { items ->
                    sharedFlowViewModel.setReviewQueue(items)
                    navController.navigate(Routes.SWIPE)
                },
                onOpenRecentlyDeleted = { navController.navigate(Routes.RECENTLY_DELETED) },
                onOpenSuggestions = { navController.navigate(Routes.SUGGESTIONS) },
            )
        }

        composable(
            route = Routes.CATEGORY,
            arguments = listOf(navArgument("category") { type = NavType.StringType }),
        ) { backStackEntry ->
            val categoryName = backStackEntry.arguments?.getString("category") ?: StorageCategory.PHOTOS.name
            val category = runCatching { StorageCategory.valueOf(categoryName) }.getOrDefault(StorageCategory.PHOTOS)
            val vm: CategoryGridViewModel = viewModel(factory = factory)
            CategoryGridScreen(
                category = category,
                viewModel = vm,
                onBack = { navController.popBackStack() },
                onDeleteSelected = { items ->
                    sharedFlowViewModel.stageAction(
                        items = items,
                        type = PendingActionType.TRASH,
                        title = "Delete ${items.size} items",
                    )
                    navController.navigate(Routes.CONFIRM)
                },
                onSwipeInstead = { items ->
                    sharedFlowViewModel.setReviewQueue(items)
                    navController.navigate(Routes.SWIPE)
                },
            )
        }

        composable(Routes.SWIPE) {
            val vm: SwipeReviewViewModel = viewModel(factory = factory)
            val queue by sharedFlowViewModel.reviewQueue.collectAsState()
            SwipeReviewScreen(
                items = queue,
                viewModel = vm,
                onBack = { navController.popBackStack() },
                onFinishReview = { toDelete ->
                    if (toDelete.isEmpty()) {
                        navController.popBackStack()
                    } else {
                        sharedFlowViewModel.stageAction(
                            items = toDelete,
                            type = PendingActionType.TRASH,
                            title = "Delete ${toDelete.size} items",
                        )
                        navController.navigate(Routes.CONFIRM)
                    }
                },
            )
        }

        composable(Routes.CONFIRM) {
            val vm: ConfirmDeleteViewModel = viewModel(factory = factory)
            val pendingAction by sharedFlowViewModel.pendingAction.collectAsState()
            ConfirmDeleteScreen(
                pendingAction = pendingAction,
                viewModel = vm,
                onDone = {
                    sharedFlowViewModel.clearPendingAction()
                    navController.popBackStack(Routes.DASHBOARD, inclusive = false)
                },
                onCancel = {
                    sharedFlowViewModel.clearPendingAction()
                    navController.popBackStack()
                },
            )
        }

        composable(Routes.RECENTLY_DELETED) {
            val vm: RecentlyDeletedViewModel = viewModel(factory = factory)
            RecentlyDeletedScreen(
                viewModel = vm,
                onBack = { navController.popBackStack() },
                onRestore = { items ->
                    sharedFlowViewModel.stageAction(items, PendingActionType.RESTORE, "Restore ${items.size} items")
                    navController.navigate(Routes.CONFIRM)
                },
                onDeleteForever = { items ->
                    sharedFlowViewModel.stageAction(
                        items,
                        PendingActionType.PERMANENT_DELETE,
                        "Permanently delete ${items.size} items (${formatBytes(items.sumOf { it.sizeBytes })})",
                    )
                    navController.navigate(Routes.CONFIRM)
                },
            )
        }

        composable(Routes.SUGGESTIONS) {
            val vm: SmartSuggestionsViewModel = viewModel(factory = factory)
            SmartSuggestionsScreen(
                viewModel = vm,
                onBack = { navController.popBackStack() },
                onReviewWithSwipe = { items ->
                    sharedFlowViewModel.setReviewQueue(items)
                    navController.navigate(Routes.SWIPE)
                },
            )
        }
    }
}
