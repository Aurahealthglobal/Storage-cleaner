package com.storagecleaner.app.data.model

import android.net.Uri

enum class MediaType { IMAGE, VIDEO }

enum class StorageCategory(val label: String) {
    PHOTOS("Photos"),
    VIDEOS("Videos"),
    SCREENSHOTS("Screenshots"),
    MESSAGING_MEDIA("WhatsApp / Telegram"),
    DOWNLOADS("Downloads"),
    EDITOR_FILES("Editing App Files"),
    LARGE_FILES("Large Files"),
    DUPLICATES("Duplicates"),
}

/** One photo or video, as read from MediaStore. */
data class MediaItem(
    val id: Long,
    val uri: Uri,
    val displayName: String,
    val mediaType: MediaType,
    val sizeBytes: Long,
    val dateAddedEpochSeconds: Long,
    val dateModifiedEpochSeconds: Long,
    val durationMillis: Long?,
    val widthPx: Int,
    val heightPx: Int,
    val relativePath: String,
    val bucketName: String,
    val volumeName: String,
    val isOnRemovableVolume: Boolean,
    val isTrashed: Boolean,
) {
    val isLarge: Boolean get() = sizeBytes > LARGE_FILE_THRESHOLD_BYTES

    companion object {
        const val LARGE_FILE_THRESHOLD_BYTES: Long = 50L * 1024 * 1024
        const val OLD_EXPORT_THRESHOLD_DAYS = 30
    }
}

/** One storage volume (internal shared storage, or a removable SD card). */
data class StorageVolumeInfo(
    val volumeName: String,
    val displayName: String,
    val isRemovable: Boolean,
    val totalBytes: Long,
    val freeBytes: Long,
) {
    val usedBytes: Long get() = (totalBytes - freeBytes).coerceAtLeast(0)
}

/** Aggregated bytes used by one category, for the dashboard breakdown bar. */
data class CategoryBreakdown(
    val category: StorageCategory,
    val itemCount: Int,
    val totalBytes: Long,
)

/** A cluster of items considered duplicates/near-duplicates of each other. */
data class DuplicateGroup(
    val id: String,
    val items: List<MediaItem>,
    val reason: String,
) {
    /** Bytes reclaimable by keeping just the largest item and removing the rest. */
    val reclaimableBytes: Long get() = items.drop(1).sumOf { it.sizeBytes }
}

/** One trashed item, with the app's own 7-day countdown (see TrashTracker). */
data class TrashedItem(
    val media: MediaItem,
    val daysRemaining: Int?,
)
