package com.storagecleaner.app.ui.recentlydeleted

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Circle
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.storagecleaner.app.data.model.MediaItem
import com.storagecleaner.app.data.model.TrashedItem
import com.storagecleaner.app.ui.components.EmptyState
import com.storagecleaner.app.ui.components.LoadingIndicator
import com.storagecleaner.app.ui.components.MediaThumbnail
import com.storagecleaner.app.ui.theme.AccentDelete

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecentlyDeletedScreen(
    viewModel: RecentlyDeletedViewModel,
    onBack: () -> Unit,
    onRestore: (List<MediaItem>) -> Unit,
    onDeleteForever: (List<MediaItem>) -> Unit,
) {
    val state by viewModel.uiState.collectAsState()
    val hasSelection = state.selectedIds.isNotEmpty()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (hasSelection) "${state.selectedIds.size} selected" else "Recently Deleted") },
                navigationIcon = {
                    IconButton(onClick = if (hasSelection) viewModel::clearSelection else onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (state.items.isNotEmpty()) {
                        IconButton(onClick = viewModel::selectAll) {
                            Icon(Icons.Filled.DoneAll, contentDescription = "Select all")
                        }
                    }
                },
            )
        },
        bottomBar = {
            if (hasSelection) {
                Surface(tonalElevation = 3.dp) {
                    Row(
                        modifier = Modifier.padding(16.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        OutlinedButton(onClick = { onRestore(state.selectedMediaItems) }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.Restore, contentDescription = null, modifier = Modifier.padding(end = 6.dp))
                            Text("Restore")
                        }
                        Button(
                            onClick = { onDeleteForever(state.selectedMediaItems) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        ) {
                            Text("Delete forever")
                        }
                    }
                }
            }
        },
    ) { padding ->
        when {
            state.isLoading -> LoadingIndicator(modifier = Modifier.padding(padding), label = "Loading trash…")
            state.items.isEmpty() -> EmptyState(
                modifier = Modifier.padding(padding),
                title = "Nothing in the trash",
                subtitle = "Deleted photos and videos stay here for 7 days before permanent removal.",
            )
            else -> Column(modifier = Modifier.padding(padding)) {
                if (!hasSelection && state.expiredItems.isNotEmpty()) {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(16.dp, 12.dp, 16.dp, 0.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                "${state.expiredItems.size} items have been here 7+ days",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(onClick = { onDeleteForever(state.expiredItems.map { it.media }) }) {
                                Text("Delete them now")
                            }
                        }
                    }
                }
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 100.dp),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    items(state.items, key = { it.media.id }) { trashedItem ->
                        TrashedGridItem(
                            trashedItem = trashedItem,
                            isSelected = trashedItem.media.id in state.selectedIds,
                            onToggle = { viewModel.toggleSelection(trashedItem) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TrashedGridItem(trashedItem: TrashedItem, isSelected: Boolean, onToggle: () -> Unit) {
    Box(
        modifier = Modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onToggle),
    ) {
        MediaThumbnail(item = trashedItem.media, modifier = Modifier.fillMaxSize())
        if (isSelected) {
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.35f)))
        }
        Icon(
            imageVector = if (isSelected) Icons.Filled.CheckCircle else Icons.Filled.Circle,
            contentDescription = if (isSelected) "Selected" else "Not selected",
            tint = if (isSelected) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.85f),
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(6.dp)
                .size(22.dp)
                .clip(CircleShape)
                .background(if (isSelected) Color.White else Color.Black.copy(alpha = 0.3f)),
        )
        val days = trashedItem.daysRemaining
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(4.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(if ((days ?: 99) <= 1) AccentDelete.copy(alpha = 0.85f) else Color.Black.copy(alpha = 0.6f))
                .padding(horizontal = 5.dp, vertical = 2.dp),
        ) {
            Text(
                text = when {
                    days == null -> "Trashed"
                    days <= 0 -> "Expiring"
                    else -> "$days d left"
                },
                color = Color.White,
                style = MaterialTheme.typography.labelSmall,
            )
        }
    }
}
