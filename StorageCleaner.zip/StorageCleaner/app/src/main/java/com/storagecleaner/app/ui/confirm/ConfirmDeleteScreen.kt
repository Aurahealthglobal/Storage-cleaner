package com.storagecleaner.app.ui.confirm

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.storagecleaner.app.ui.components.MediaThumbnail
import com.storagecleaner.app.ui.components.SystemActionLauncherEffect
import com.storagecleaner.app.ui.shared.PendingAction
import com.storagecleaner.app.ui.shared.PendingActionType
import com.storagecleaner.app.util.formatBytes

/**
 * The one confirmation screen every delete/restore flow routes through
 * (swipe review, category-grid batch delete, recently-deleted restore/
 * empty) — see README.md "One confirmation screen, by design". Tapping
 * Confirm here triggers the actual MediaStore system dialog via
 * SystemActionLauncherEffect.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConfirmDeleteScreen(
    pendingAction: PendingAction?,
    viewModel: ConfirmDeleteViewModel,
    onDone: () -> Unit,
    onCancel: () -> Unit,
) {
    val uiState by viewModel.uiState.collectAsState()
    val intentSender by viewModel.currentIntentSender.collectAsState()

    SystemActionLauncherEffect(pendingIntentSender = intentSender, onResult = viewModel::onDialogResult)

    LaunchedEffect(uiState.isDone) {
        if (uiState.isDone) onDone()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Confirm") },
                navigationIcon = {
                    IconButton(onClick = onCancel) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Cancel")
                    }
                },
            )
        },
    ) { padding ->
        if (pendingAction == null) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("Nothing to confirm.")
            }
            return@Scaffold
        }

        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
            val actionVerb = when (pendingAction.type) {
                PendingActionType.TRASH -> "move to Recently Deleted"
                PendingActionType.PERMANENT_DELETE -> "permanently delete"
                PendingActionType.RESTORE -> "restore"
            }
            val totalBytes = pendingAction.items.sumOf { it.sizeBytes }

            Text(pendingAction.title, style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                "You're about to $actionVerb ${pendingAction.items.size} items, freeing ${formatBytes(totalBytes)}.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (pendingAction.type == PendingActionType.TRASH) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "They'll stay in Recently Deleted for 7 days before permanent removal.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (pendingAction.type == PendingActionType.PERMANENT_DELETE) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "This can't be undone.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(pendingAction.items.take(30), key = { it.id }) { item ->
                    MediaThumbnail(
                        item = item,
                        sizePx = 200,
                        modifier = Modifier.size(84.dp).clip(RoundedCornerShape(10.dp)),
                    )
                }
            }
            if (pendingAction.items.size > 30) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    "+${pendingAction.items.size - 30} more",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = { viewModel.confirm(pendingAction) },
                enabled = !uiState.isProcessing,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (pendingAction.type == PendingActionType.RESTORE) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.error
                    },
                ),
            ) {
                if (uiState.isProcessing) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                } else {
                    Text("Confirm")
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedButton(onClick = onCancel, modifier = Modifier.fillMaxWidth(), enabled = !uiState.isProcessing) {
                Text("Cancel")
            }

            if (uiState.wasCancelled) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "Cancelled — nothing was changed.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
    }
}
