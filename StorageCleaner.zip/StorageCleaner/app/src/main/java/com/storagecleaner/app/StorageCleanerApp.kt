package com.storagecleaner.app

import android.app.Application
import coil3.ImageLoader
import coil3.PlatformContext
import coil3.SingletonImageLoader
import com.storagecleaner.app.core.AppContainer
import com.storagecleaner.app.thumbnail.MediaThumbnailFetcher

class StorageCleanerApp : Application(), SingletonImageLoader.Factory {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }

    override fun newImageLoader(context: PlatformContext): ImageLoader =
        ImageLoader.Builder(context)
            .components { add(MediaThumbnailFetcher.Factory(contentResolver)) }
            .crossfade(true)
            .build()
}
