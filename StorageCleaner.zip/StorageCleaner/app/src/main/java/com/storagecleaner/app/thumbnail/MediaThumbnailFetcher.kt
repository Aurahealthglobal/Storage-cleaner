package com.storagecleaner.app.thumbnail

import android.content.ContentResolver
import android.net.Uri
import android.util.Size
import coil3.ImageLoader
import coil3.asImage
import coil3.decode.DataSource
import coil3.fetch.FetchResult
import coil3.fetch.Fetcher
import coil3.fetch.ImageFetchResult
import coil3.request.Options

/** What to load: which MediaStore item, and roughly what pixel size to render it at. */
data class MediaThumbnailRequest(val uri: Uri, val targetSizePx: Int = 300)

/**
 * Coil3 fetcher that loads MediaStore thumbnails via
 * ContentResolver#loadThumbnail — the same unified API the platform's
 * own gallery uses for both photo AND video thumbnails, so no separate
 * video-frame-decoding dependency is needed just to show a video's
 * poster frame in the grid.
 *
 * Keyed on a dedicated [MediaThumbnailRequest] rather than android.net.Uri
 * directly: Coil 3's pipeline has built-in handling for android.net.Uri
 * that a custom Fetcher.Factory<Uri> would collide/compete with, so a
 * distinct request type keeps routing to this fetcher unambiguous.
 *
 * Registered once in StorageCleanerApp (SingletonImageLoader.Factory);
 * every AsyncImage in the app passes a MediaThumbnailRequest as `model`.
 */
class MediaThumbnailFetcher(
    private val request: MediaThumbnailRequest,
    private val resolver: ContentResolver,
) : Fetcher {

    override suspend fun fetch(): FetchResult {
        val size = Size(request.targetSizePx, request.targetSizePx)
        val bitmap = resolver.loadThumbnail(request.uri, size, null)
        return ImageFetchResult(
            image = bitmap.asImage(),
            isSampled = true,
            dataSource = DataSource.DISK,
        )
    }

    class Factory(private val resolver: ContentResolver) : Fetcher.Factory<MediaThumbnailRequest> {
        override fun create(
            data: MediaThumbnailRequest,
            options: Options,
            imageLoader: ImageLoader,
        ): Fetcher = MediaThumbnailFetcher(data, resolver)
    }
}
