package com.storagecleaner.app.ui.recentlydeleted

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.storagecleaner.app.core.AppContainer
import com.storagecleaner.app.data.MediaRepository
import com.storagecleaner.app.data.TrashTracker
import com.storagecleaner.app.data.model.MediaItem
import com.storagecleaner.app.data.model.TrashedItem
import com.storagecleaner.app.util.daysRemainingInTrash
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class RecentlyDeletedUiState(
    val isLoading: Boolean = true,
    val items: List<TrashedItem> = emptyList(),
    val selectedIds: Set<Long> = emptySet(),
) {
    val selectedMediaItems: List<MediaItem> get() = items.filter { it.media.id in selectedIds }.map { it.media }
    /** Trashed 7+ days ago by this app's own record — candidates the UI offers to purge now. */
    val expiredItems: List<TrashedItem> get() = items.filter { (it.daysRemaining ?: Int.MAX_VALUE) <= 0 }
}

class RecentlyDeletedViewModel(container: AppContainer) : ViewModel() {
    private val repository: MediaRepository = container.mediaRepository
    private val trashTracker: TrashTracker = container.trashTracker

    private val _uiState = MutableStateFlow(RecentlyDeletedUiState())
    val uiState: StateFlow<RecentlyDeletedUiState> = _uiState.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val trashed = repository.queryTrashed()
            val withCountdown = trashed
                .map { media ->
                    TrashedItem(
                        media = media,
                        daysRemaining = daysRemainingInTrash(trashTracker.trashedAtMillis(media.uri)),
                    )
                }
                .sortedBy { it.daysRemaining ?: Int.MAX_VALUE }
            _uiState.update { it.copy(isLoading = false, items = withCountdown, selectedIds = emptySet()) }
        }
    }

    fun toggleSelection(item: TrashedItem) {
        _uiState.update { state ->
            val id = item.media.id
            val newSelection = if (id in state.selectedIds) state.selectedIds - id else state.selectedIds + id
            state.copy(selectedIds = newSelection)
        }
    }

    fun selectAll() {
        _uiState.update { it.copy(selectedIds = it.items.map { t -> t.media.id }.toSet()) }
    }

    fun clearSelection() {
        _uiState.update { it.copy(selectedIds = emptySet()) }
    }
}
