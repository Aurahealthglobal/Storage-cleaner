package com.storagecleaner.app.ui.suggestions

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.storagecleaner.app.data.model.MediaItem
import com.storagecleaner.app.ui.components.MediaThumbnail
import com.storagecleaner.app.util.formatBytes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartSuggestionsScreen(
    viewModel: SmartSuggestionsViewModel,
    onBack: () -> Unit,
    onReviewWithSwipe: (List<MediaItem>) -> Unit,
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Smart suggestions") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
    ) { padding ->
        if (state.isLoading) {
            Column(
                modifier = Modifier.fillMaxSize().padding(padding),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                DuplicatesCard(
                    isScanning = state.isScanningDuplicates,
                    hasScanned = state.hasScannedDuplicates,
                    groupCount = state.duplicateGroups.size,
                    reclaimableBytes = state.duplicateReclaimableBytes,
                    previewItems = state.duplicateExtraItems,
                    onScan = viewModel::scanForDuplicates,
                    onReview = { onReviewWithSwipe(state.duplicateExtraItems) },
                )
            }
            item {
                SuggestionSectionCard(
                    title = state.largeFiles.title,
                    subtitle = state.largeFiles.subtitle,
                    items = state.largeFiles.items,
                    onReview = { onReviewWithSwipe(state.largeFiles.items) },
                )
            }
            item {
                SuggestionSectionCard(
                    title = state.oldExports.title,
                    subtitle = state.oldExports.subtitle,
                    items = state.oldExports.items,
                    onReview = { onReviewWithSwipe(state.oldExports.items) },
                )
            }
            item {
                SuggestionSectionCard(
                    title = state.oldScreenshots.title,
                    subtitle = state.oldScreenshots.subtitle,
                    items = state.oldScreenshots.items,
                    onReview = { onReviewWithSwipe(state.oldScreenshots.items) },
                )
            }
            item {
                SuggestionSectionCard(
                    title = state.editorFiles.title,
                    subtitle = state.editorFiles.subtitle +
                        " — matched by folder name in your public library, not private app cache (see README).",
                    items = state.editorFiles.items,
                    onReview = { onReviewWithSwipe(state.editorFiles.items) },
                )
            }
        }
    }
}

@Composable
private fun DuplicatesCard(
    isScanning: Boolean,
    hasScanned: Boolean,
    groupCount: Int,
    reclaimableBytes: Long,
    previewItems: List<MediaItem>,
    onScan: () -> Unit,
    onReview: () -> Unit,
) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.ContentCopy, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Duplicates & repeat takes", style = MaterialTheme.typography.titleMedium)
            }
            Spacer(modifier = Modifier.height(6.dp))
            when {
                isScanning -> {
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Scanning — this can take a moment on a large library…", style = MaterialTheme.typography.bodyMedium)
                    }
                }
                !hasScanned -> {
                    Text(
                        "Find visually similar photos and video takes shot moments apart. Nothing leaves your device.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(onClick = onScan) { Text("Scan for duplicates") }
                }
                groupCount == 0 -> {
                    Text("No duplicates found.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                else -> {
                    Text(
                        "$groupCount groups found — keeping the best of each frees ${formatBytes(reclaimableBytes)}.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(previewItems.take(12), key = { it.id }) { item ->
                            MediaThumbnail(
                                item = item,
                                sizePx = 180,
                                modifier = Modifier.size(64.dp).clip(RoundedCornerShape(8.dp)),
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(onClick = onReview, modifier = Modifier.fillMaxWidth()) {
                        Text("Review ${previewItems.size} extra copies")
                    }
                }
            }
        }
    }
}

@Composable
private fun SuggestionSectionCard(
    title: String,
    subtitle: String,
    items: List<MediaItem>,
    onReview: () -> Unit,
) {
    if (items.isEmpty()) return
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(formatBytes(items.sumOf { it.sizeBytes }), style = MaterialTheme.typography.titleMedium)
            }
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(10.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(items.take(12), key = { it.id }) { item ->
                    MediaThumbnail(
                        item = item,
                        sizePx = 180,
                        modifier = Modifier.size(64.dp).clip(RoundedCornerShape(8.dp)),
                    )
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Button(onClick = onReview, modifier = Modifier.fillMaxWidth()) {
                Text("Review ${items.size} items")
            }
        }
    }
}
