# Add project specific ProGuard rules here.
# Compose, Coil and Navigation all ship their own consumer R8 rules via
# their AARs, so nothing extra is required for the current feature set.
# If you add reflection-based libraries (e.g. Gson/Moshi with reflection)
# later, add -keep rules for their models here.
