# Storage Cleaner

A Kotlin + Jetpack Compose Android app for freeing up phone/SD-card storage — tuned for a content creator's storage patterns (raw takes, exports, duplicate photos, editing-app leftovers).

## What's in this build

All six build-order steps are implemented, not just the MVP:

1. **Scaffold + permissions + MediaStore queries**, with internal-vs-SD-card volume detection — `data/MediaRepository.kt`
2. **Storage dashboard** — per-volume free space, category breakdown bar — `ui/dashboard/`
3. **Category grid + multi-select + batch delete** — `ui/category/`
4. **Swipe-card review** (Tinder-style drag, running freed-space counter, undo) — `ui/swipe/`
5. **Recently Deleted + undo, 7-day countdown** — `ui/recentlydeleted/`
6. **Smart suggestions** — duplicate photos/videos, old exports, old screenshots, editor-app files, large files — `ui/suggestions/`

Every delete/trash/restore action, from any screen, routes through one shared confirmation screen (`ui/confirm/`) — which is what actually fires the single MediaStore system dialog per batch.

## Two ways to build this

- **No computer at all?** Use [Building with no computer — entirely from your phone](#building-with-no-computer--entirely-from-your-phone) below. GitHub's servers do the actual compiling; your phone just uploads code and downloads the finished APK.
- **Have a computer, even occasionally?** Use [Getting this running via Android Studio](#getting-this-running-via-android-studio) — simpler, and what you'd use for ongoing development.

---

## Building with no computer — entirely from your phone

This project has no gradle-wrapper.jar checked in (it's a compiled binary, not something that can be hand-written as text), so it can't be built by just tapping the zip. Instead, **GitHub's servers do the actual build**: you push this code to a free GitHub repository, a workflow I've included (`.github/workflows/build-apk.yml`) compiles it automatically in the cloud, and you download the finished, installable APK when it's done. Everything below is done through your phone's browser.

### Phase 1 — Get the code onto GitHub
1. Go to **github.com** and create a free account if you don't have one.
2. Tap **+ → New repository**. Name it `storage-cleaner`. Turn **on** "Add a README file" (important — this gives the repo an initial commit so the next step works). Create it.
3. On the new repo's page: green **Code** button → **Codespaces** tab → **Create codespace on main**. A code-editor screen loads in your browser — that's normal, it's your workspace.
4. In the file list on the left, tap the **⋯** menu (or long-press empty space) → **Upload...** → pick `StorageCleaner.zip` from your phone. Wait for it to finish uploading.
5. Open the **Terminal** (menu → Terminal → New Terminal, or the terminal icon at the bottom). Paste this whole block in and hit enter — it unzips everything into place and pushes it:
   ```
   unzip StorageCleaner.zip
   shopt -s dotglob
   mv StorageCleaner/* .
   rmdir StorageCleaner
   rm StorageCleaner.zip
   git add -A
   git commit -m "Add Storage Cleaner project"
   git push
   ```
   It may ask you to sign in to git the first time (follow the on-screen prompt) — then re-run `git push`.

### Phase 2 — Let it build
6. Back on github.com (not Codespaces), open your repo → **Actions** tab. You should see "Build debug APK" running (a yellow dot). First build takes 5–10 minutes — it's downloading everything from scratch.
7. When it turns into a green checkmark, tap into that run, scroll to **Artifacts**, and tap **storage-cleaner-debug-apk** to download it (comes as a small zip).

### Phase 3 — Install it
8. Extract that small zip with your phone's file manager — inside is `app-debug.apk`.
9. Tap `app-debug.apk`. Android will likely block it the first time and offer a settings shortcut to allow installs from that app (your browser or file manager) — allow it, then go back and tap the APK again.
10. Open **Storage Cleaner**, grant photo/video access, and you're in.

If step 6 shows a **red ✗** instead of a checkmark, tap into the run to see which step failed and copy the error — I can debug it from that; I couldn't compile this myself before handing it over, so this cloud build is genuinely the first real compile it's getting.

---

## Getting this running via Android Studio

You need Android Studio for this path — there's no way around it for a hand-written Kotlin project.

1. **Install Android Studio** (free) if you don't have it: https://developer.android.com/studio
2. **Unzip** this project, then in Android Studio: **File → Open**, and select the unzipped `StorageCleaner` folder.
3. Wait for **Gradle sync** to finish (first sync downloads dependencies — a couple of minutes on a normal connection). If Android Studio prompts that the Gradle wrapper JAR is missing, accept its offer to regenerate it — see "About the Gradle wrapper" below.
4. **Connect your phone**: Settings → About phone → tap "Build number" 7 times (enables Developer Options) → Settings → Developer options → enable **USB debugging** → plug in via USB (or set up Wireless debugging from the same menu).
5. Pick your device from Android Studio's device dropdown (top toolbar) and hit **Run ▶**.
6. First launch asks for photo/video access — grant it ("Select photos and videos" also works, and you can widen that later).

No emulator needed — this app is more useful tested against your real library anyway.

### About the Gradle wrapper
`gradle-wrapper.properties` is included (pinned to Gradle 9.5.1), but not the wrapper JAR binary — that's a compiled file I can't reliably hand-write as text. Android Studio regenerates it automatically on first open in virtually all cases. If it somehow doesn't, run `gradle wrapper` once from a terminal with any Gradle installation, or use Android Studio's own bundled Gradle to sync directly.

## Important: I could not compile this myself

I wrote and cross-checked this project carefully — imports, method signatures, and every cross-file reference were verified in a pass after writing (see the grep-based checks earlier in this conversation) — and I checked the fast-moving Android APIs (permissions, MediaStore trash/delete behavior, current library versions, Play Store policy) against live documentation while building it rather than from memory alone. But my build environment has no Android SDK and no network access to resolve Gradle dependencies, so **this has not actually been compiled**. Treat your first Gradle sync in Android Studio as the real first build. If something doesn't resolve, it's most likely a dependency patch version (Android Studio's Upgrade Assistant fixes those in one click) rather than a structural problem — everything that touches cross-file wiring was checked by hand.

## Design decisions worth knowing about

- **minSdk 30 (Android 11).** Deliberate, not an oversight: `MediaStore.createDeleteRequest()` / `createTrashRequest()` — the batched, single-dialog delete flow the whole app is built around — are API 30+ only.
- **Recently Deleted uses MediaStore's real trash flag**, not a custom copy-to-app-storage bin. Trashing is a metadata flip (`IS_TRASHED`), not a file copy, so it doesn't need extra disk space at the exact moment you're trying to free some. The OS's own auto-purge timing isn't a documented fixed number of days, so the app tracks its own 7-day countdown locally (`data/TrashTracker.kt`) and offers to purge expired items — with one more tap, since Android requires user confirmation for any permanent delete of media the app doesn't own.
- **"Editing App Files" scans public folders only** (DCIM/Movies/Pictures, matched by folder name — CapCut, InShot, VN, KineMaster, etc.), not private app cache. I checked Google Play's current policy while building this: apps whose justification for the "All files access" (`MANAGE_EXTERNAL_STORAGE`) permission is photo/video file management are explicitly listed as an **invalid use case**. So this app never requests that permission at all — everything goes through MediaStore + the Storage Access Framework instead, which is also more likely to actually get through Play review. The tradeoff: it won't reach a truly private per-app cache folder (Android itself has locked those down from other apps since Android 11 regardless).
- **Dashboard's category bar is mutually exclusive** — each item counts in exactly one segment, so the bar's segments add up to the real total. Large Files and Duplicates are cross-cutting (a large file is still a Photo or a Video), so they're separate callout cards instead of bar segments.
- **No Room, no Hilt.** Manual DI (`core/AppContainer.kt`) and in-memory/SharedPreferences state only — fewer moving parts to go wrong in a build I couldn't test end-to-end. Straightforward to introduce either later if the app grows past this.
- **Duplicate detection is on-device and ML-free**: an 8x8 average-hash for photos, metadata clustering (duration/size/creation-time) for videos — see `data/DuplicateDetector.kt`. It's a deliberate, user-triggered scan (not automatic) since hashing a large photo library takes real time.

## Before you publish to Play Store

- **Permissions Declaration**: broad `READ_MEDIA_IMAGES`/`READ_MEDIA_VIDEO` access is a Play "restricted permission" — you'll need to fill out a Permissions Declaration Form in Play Console before publishing. A whole-library storage manager is the textbook approved "gallery-app-like" use case, but the declaration step is manual, not automatic — budget time for that review.
- **Target API 36**: Google requires new apps/updates to target Android 16 (API 36) as of August 31, 2026 — already set in `app/build.gradle.kts`.
- **App icon** is a hand-drawn vector placeholder (`res/drawable/ic_launcher_*.xml`, using the same storage-bar motif as the dashboard) — swap it for real branding via Android Studio's Image Asset Studio when you're ready.

## Project structure

```
app/src/main/java/com/storagecleaner/app/
├── data/                 MediaStore repository, delete/trash requests, duplicate
│                         detection, SAF (SD card), permissions
├── thumbnail/            Coil3 fetcher using ContentResolver.loadThumbnail
│                         (works for photo AND video thumbnails, no extra dependency)
├── core/                 Manual DI container + generic ViewModel factory
├── ui/
│   ├── dashboard/        Storage bar, per-volume free space, category list
│   ├── category/         Multi-select grid + batch delete
│   ├── swipe/             Tinder-style review
│   ├── confirm/           The one shared confirmation screen
│   ├── recentlydeleted/   Trash grid with countdown badges
│   ├── suggestions/       Duplicates, old exports, screenshots, editor files
│   ├── permissions/       First-run permission gate
│   ├── shared/            Cross-screen state (avoids passing big lists as nav args)
│   ├── components/        Reusable composables (storage bar, thumbnails, system-dialog launcher)
│   └── theme/             Dark-first Material3 theme
├── MainActivity.kt
└── StorageCleanerApp.kt   Application class
```

## What to try first

1. Run it, grant photo/video access.
2. Dashboard shows your real storage breakdown immediately — internal storage and SD card (if present) as separate cards, category bar below.
3. Tap a category → multi-select (long-press or tap a thumbnail) → "Delete selected", **or** tap "Quick swipe review — everything" from the dashboard for the Tinder-style flow.
4. Smart Suggestions → "Scan for duplicates" — this is the one operation that takes real time on a big library, since it's hashing photos on-device.
5. Delete a few things, then check Recently Deleted — restore one, and look at the "days left" badges.
